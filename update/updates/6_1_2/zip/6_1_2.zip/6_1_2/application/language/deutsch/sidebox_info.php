<?php

/**
 * Note to module developers:
 * 	Keeping a module specific language file like this
 *	in this external folder is not a good practise for
 *	portability - I do not advice you to do this for
 *	your own modules since they are non-default.
 *	Instead, simply put your language files in
 *	application/modules/yourModule/language/
 *	You do not need to change any code, the system
 *	will automatically look in that folder too.
 */
 
 /* translated by Rydik from http://sunrise-aion.com */

$lang['expansion'] = "Expansion";
$lang['last_ip'] = "Letzte IP";
$lang['current_ip'] = "Derzeitige IP";
$lang['vp'] = "VP";
$lang['dp'] = "DP";
$lang['user_panel'] = "Account Verwaltung";
$lang['log_out'] = "Ausloggen";
$lang['username'] = "Username";
$lang['password'] = "Passwort";
$lang['log_in'] = "Einloggen";