<?php

$config['FusionCMSVersion'] = '6.1.1';